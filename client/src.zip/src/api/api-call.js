import { client } from "@/utils/helper";




const getProducts = async () => {
    const response = await client.get("product", {
        headers: {
            "Cache-Control": "no-store",
        },
    });

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};

const getcategories = async () => {
    const response = await client.get("category", {
        headers: {
            "Cache-Control": "no-store",
        },
    });

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};





const getbrands = async () => {
    const response = await client.get("brand", {
        headers: {
            "Cache-Control": "no-store",
        },
    });

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};

const getcolors = async () => {
    const response = await client.get("color", {
        headers: {
            "Cache-Control": "no-store",
        },
    });

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};



const getcategoriesById = async (id) => {
    const response = await client.get(`category/${id}`);

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};

const getProductById = async (id) => {
    const response = await client.get(`product/${id}`);

    if (!response.data.success) {
        throw new Error(response.data.message || "API Fail");
    }

    return response.data
};

export { getcategories, getcategoriesById, getbrands, getcolors, getProducts,getProductById };

