'use client'
import { FaShoppingCart, FaSearch, FaBars } from "react-icons/fa";
import { useState } from "react";

export default function Header() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <header className="bg-white shadow-md sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">

                {/* Logo */}
                <h1 className="text-2xl font-bold text-blue-600 cursor-pointer">
                    ShopEasy
                </h1>

                {/* Search Bar */}
                <div className="hidden md:flex items-center w-1/3 border rounded-lg px-3 py-2">
                    <FaSearch className="text-gray-500" size={18} />
                    <input
                        type="text"
                        placeholder="Search products..."
                        className="ml-2 w-full outline-none"
                    />
                </div>

                {/* Desktop Nav */}
                <nav className="hidden md:flex items-center gap-6">
                    <a href="#" className="hover:text-blue-600">Home</a>
                    <a href="#" className="hover:text-blue-600">Shop</a>
                    <a href="#" className="hover:text-blue-600">Categories</a>
                    <a href="#" className="hover:text-blue-600">Contact</a>
                </nav>

                {/* Right Section */}
                <div className="flex items-center gap-4">
                    <FaShoppingCart className="cursor-pointer" />

                    <button className="hidden md:block bg-blue-600 text-white px-4 py-1 rounded-lg hover:bg-blue-700">
                        Login
                    </button>

                    {/* Mobile Menu Button */}
                    <FaBars
                        className="md:hidden cursor-pointer"
                        onClick={() => setIsOpen(!isOpen)}
                    />
                </div>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <div className="md:hidden px-4 pb-4">
                    <a href="#" className="block py-2">Home</a>
                    <a href="#" className="block py-2">Shop</a>
                    <a href="#" className="block py-2">Categories</a>
                    <a href="#" className="block py-2">Contact</a>

                    <button className="w-full mt-2 bg-blue-600 text-white py-2 rounded-lg">
                        Login
                    </button>
                </div>
            )}
        </header>
    );
}