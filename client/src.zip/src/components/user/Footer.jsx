'use client'
import { FaFacebookF, FaInstagram, FaTwitter } from "react-icons/fa";

export default function Footer() {
    return (
        <footer className="bg-gray-900 text-gray-300 mt-10">
            <div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-8">

                {/* Logo + About */}
                <div>
                    <h2 className="text-2xl font-bold text-white mb-3">ShopEasy</h2>
                    <p className="text-sm">
                        Your one-stop shop for all your needs. Best products, best prices.
                    </p>
                </div>

                {/* Quick Links */}
                <div>
                    <h3 className="text-white font-semibold mb-3">Quick Links</h3>
                    <ul className="space-y-2 text-sm">
                        <li><a href="#" className="hover:text-white">Home</a></li>
                        <li><a href="#" className="hover:text-white">Shop</a></li>
                        <li><a href="#" className="hover:text-white">Categories</a></li>
                        <li><a href="#" className="hover:text-white">Contact</a></li>
                    </ul>
                </div>

                {/* Categories */}
                <div>
                    <h3 className="text-white font-semibold mb-3">Categories</h3>
                    <ul className="space-y-2 text-sm">
                        <li><a href="#" className="hover:text-white">Electronics</a></li>
                        <li><a href="#" className="hover:text-white">Fashion</a></li>
                        <li><a href="#" className="hover:text-white">Home</a></li>
                        <li><a href="#" className="hover:text-white">Beauty</a></li>
                    </ul>
                </div>

                {/* Newsletter */}
                <div>
                    <h3 className="text-white font-semibold mb-3">Subscribe</h3>
                    <p className="text-sm mb-2">Get latest updates & offers</p>
                    <div className="flex">
                        <input
                            type="email"
                            placeholder="Enter email"
                            className="w-full px-2 py-2 rounded-l-md outline-none text-black"
                        />
                        <button className="bg-blue-600 px-4 rounded-r-md text-white hover:bg-blue-700">
                            Send
                        </button>
                    </div>

                    {/* Social Icons */}
                    <div className="flex gap-4 mt-4 text-lg">
                        <FaFacebookF className="cursor-pointer hover:text-white" />
                        <FaInstagram className="cursor-pointer hover:text-white" />
                        <FaTwitter className="cursor-pointer hover:text-white" />
                    </div>
                </div>
            </div>

            {/* Bottom */}
            <div className="border-t border-gray-700 text-center py-4 text-sm">
                © 2026 ShopEasy. All rights reserved.
            </div>
        </footer>
    );
}