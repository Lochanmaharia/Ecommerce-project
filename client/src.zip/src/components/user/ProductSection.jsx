"use client";
import { FaShoppingCart, FaHeart } from "react-icons/fa";

const products = [
    {
        id: 1,
        title: "Wireless Headphones",
        price: 1999,
        image: "https://images.unsplash.com/photo-1580894908361-967195033215?q=80&w=800&auto=format&fit=crop",
    },
    {
        id: 2,
        title: "Smart Watch",
        price: 2999,
        image: "https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?q=80&w=800&auto=format&fit=crop",
    },
    {
        id: 3,
        title: "Running Shoes",
        price: 1499,
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=800&auto=format&fit=crop",
    },
    {
        id: 4,
        title: "Backpack",
        price: 999,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800&auto=format&fit=crop",
    },
];

export default function ProductSection() {
    return (
        <section className="bg-gray-100 px-30 py-12">

            <h1 className="text-3xl font-bold mb-10 text-center text-gray-800">
                🛒 Featured Products
            </h1>

            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

                {products.map((product) => (
                    <div
                        key={product.id}
                        className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl hover:-translate-y-1 transition duration-300"
                    >

                        <div className="relative group">
                            <img
                                src={product.image}
                                alt={product.title}
                                className="w-full h-52 object-cover"
                            />

                            {/* ✅ Fixed */}
                            <FaHeart className="absolute top-3 right-3 text-gray-600 hover:text-red-500 cursor-pointer" />

                            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                                <button className="bg-blue-600 px-4 py-2 rounded-lg text-white flex items-center gap-2 hover:bg-blue-700">

                                    {/* ✅ Fixed */}
                                    <FaShoppingCart size={18} />

                                    Add to Cart
                                </button>
                            </div>
                        </div>

                        <div className="p-4">
                            <h2 className="text-lg font-semibold text-gray-800 line-clamp-1">
                                {product.title}
                            </h2>

                            <p className="text-gray-500 mt-2">
                                ₹{product.price}
                            </p>
                        </div>

                    </div>
                ))}

            </div>
        </section>
    );
}