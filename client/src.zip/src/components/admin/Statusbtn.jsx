"use client"

import { client, notify } from "@/utils/helper";
import { useRouter } from "next/navigation";
function StatusBtn({ value, id, field }) {
    const router = useRouter();

    function StatusHandler() {
        client
            .patch(`category/status-update/${id}`, { field }).then(
                (response) => {
                    notify(response.data.message, response.data.success)
                    if (response.data.success) {
                        router.refresh();
                    }
                }
            ).catch(
                (error) => {
                    const message = err?.response?.data?.message || "Internal Server Error";
                    notify(message, false)
                }
            )
    }
    const lable = {
        status: ["Active", "Inactive"],
        is_home: ["Home", "Not Home"],
        is_top: ["Top", "Not Top"],
        is_popular: ["Popular", "Not Popular"]
    }
    const [TrueLable, FalseLable] = lable[field] || { "YES": "NO" };

    const base = "px-3 py-1 rounded-full text-xs font-medium";
    return (
        <button onClick={StatusHandler} className={`${base}
            ${value ? " bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}
        >
            {value ? TrueLable : FalseLable}
        </button>
    );
}

export default StatusBtn;