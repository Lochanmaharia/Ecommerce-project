
'use client'
import { use } from 'react'
import React, { useRef, useState, useEffect } from "react";
import Link from "next/link";
import { client } from "@/utils/helper";
import { notify } from "@/utils/helper";
import { useRouter } from "next/navigation";
import { getProductById } from '@/api/api-call';


export default function EditCategory({ params }) {

    const [image, setImage] = useState()
    const { id } = use(params)
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [fetchLoading, setfetchLoading] = useState(false);
    const [product, setProduct] = useState({});
    let baseUrl = "";


    // const SubmitHandler = (event) => {
    //     event.preventDefault();

    //     const payload = new FormData();
    //     payload.append("image", event.target.image.files[0]);
    //     payload.append("name", nameRef.current.value);
    //     payload.append("slug", slugRef.current.value);

    //     setLoading(true);

    //     client
    //         .put(`category/update/${id}`, payload)
    //         .then((response) => {
    //             notify(response.data.message, response.data.success);
    //             if (response.data.success) {
    //                 nameRef.current.value = "";
    //                 slugRef.current.value = "";
    //                 router.push("/admin/category");
    //             }
    //         })
    //         .catch((err) => {
    //             console.log(err);
    //             const message =
    //                 err?.response?.data?.message || "Internal Server Error";
    //             notify(message, false);
    //         })
    //         .finally(() => {
    //             setLoading(false);
    //         });
    // };


    async function getProduct() {
        setfetchLoading(true)
        try {

            const { data, meta } = await getProductById(id)
            setProduct(data)
            baseUrl = meta?.imageBaseUrl;


        } catch (error) {
            console.log(error);

        } finally {
            setfetchLoading(false)
        }
    }
    useEffect(
        () => {
            getProduct()
        },
        [id]
    )


    if (fetchLoading) {
        return (
            <h2 className='h-screen flex justify-center items-center text-3xl font-bold '>Loading...</h2>
        )
    }

    console.log(product, "product");


    return (
        <div className="flex items-center justify-center bg-gray-50 p-6 rounded-2xl">

            {/* Card */}
            <div className="w-full max-w-5xl mt-5 bg-white/80 backdrop-blur-lg shadow-2xl rounded-3xl border border-gray-100 p-8">

                {/* Header */}
                <div className="mb-8 text-center">
                    <h1 className="text-3xl font-bold text-gray-800 tracking-tight">
                        Add Images
                    </h1>

                </div>

                {/* Form */}
                <form className="space-y-6">


                    {/*  IMAGE  */}
                    <div>
                        <label className="text-sm font-semibold mb-2 text-gray-700">
                            Image
                        </label>
                        <div className="w-full bg-gray-100 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:border-orange-400 transition">
                            <label htmlFor="imageUpload" className="cursor-pointer flex flex-col items-center justify-center gap-2">


                                <div className="text-gray-400 text-3xl">
                                    📷
                                </div>


                                <p className="text-gray-500 text-sm">
                                    Click to upload or drag & drop
                                </p>

                                <p className="text-xs text-gray-400">
                                    PNG, JPG (optional)
                                </p>
                            </label>

                            <input
                                type="file"
                                multiple
                                name="image"
                                accept="image/"
                                className=" mt-3 ml-26"
                            />
                        </div>
                        <img src={image} alt="" className='h-45 w-30 my-2 rounded-3xl' />

                        <p className="text-xs text-gray-400 mt-2">
                            Upload category thumbnail (optional)
                        </p>
                    </div>




                    {/* Buttons */}
                    <div className="flex  gap-4 pt-4 w-md">

                        <button
                            type="submit"
                            disabled={loading}
                            className="flex-1 bg-linear-to-r from-orange-500 to-orange-600 text-white py-2.5 rounded-xl font-medium shadow-md hover:scale-105 transition duration-200"
                        >
                            {loading ? "update....." : "Add Images"}
                        </button>

                        <Link href="/admin/category" className="flex-1">
                            <button
                                type="button"
                                className="w-full bg-gray-100 text-gray-700 py-2.5 rounded-xl font-medium hover:bg-gray-200 transition"
                            >
                                Cancel
                            </button>
                        </Link>

                    </div>
                </form>
            </div>
        </div>
    );
}