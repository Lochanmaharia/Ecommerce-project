import ProductSection from '@/components/user/ProductSection'
import React from 'react'

export default function home() {
  return (
    <ProductSection />
  )
}
